#DESAFIO 1b INTRODUCCION A PYTHON

# datos
p = float(input("Ingrese el precio de suscripción: "))
u = int(input("Ingrese el número de usuarios: "))
gt = float(input("Ingrese los gastos totales: "))

#ecuacion
utilidades = p * u - gt

print("Las utilidades del proyecto son:", utilidades)
